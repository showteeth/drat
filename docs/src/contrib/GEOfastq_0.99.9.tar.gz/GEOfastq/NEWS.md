# GEOfastq 0.99.0

* Submitted to Bioconductor


# GEOfastq 0.6.5

* Resolved NOTES from `BiocCheck::BiocCheck()`
    + added unit tests
    + replaced `sapply` with `vapply`
    + shortened lines
    + added a `NEWS.md` file to track changes to the package.
