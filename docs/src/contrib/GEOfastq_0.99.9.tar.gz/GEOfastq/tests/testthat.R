library(testthat)
library(GEOfastq)

test_check("GEOfastq")
