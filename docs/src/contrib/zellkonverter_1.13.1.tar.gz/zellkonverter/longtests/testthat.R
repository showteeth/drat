library(testthat)
library(zellkonverter)

test_check("zellkonverter")
